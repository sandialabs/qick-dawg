This example shows the metadata capabilities of the name server (Since Pyro 4.40)
and the use of the PYROMETA magic uri protocol (since Pyro 4.51)

Before running the example.py, make sure the name server is running.
You should choose an appropriate storage type for the name server
(dbm storage doesn't support metadata).
