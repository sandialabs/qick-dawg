:mod:`Pyro4.naming` --- Pyro name server
========================================

.. automodule:: Pyro4.naming
   :members:

.. autoclass:: Pyro4.naming.NameServer
   :members:

.. automodule:: Pyro4.naming_storage
   :members:
