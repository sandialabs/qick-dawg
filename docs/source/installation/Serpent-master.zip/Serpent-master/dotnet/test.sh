#!/bin/sh
echo "Running tests"
dotnet test Serpent/Tests
